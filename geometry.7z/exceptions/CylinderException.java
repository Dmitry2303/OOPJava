package exceptions;

public class CylinderException extends Exception {
    public CylinderException(String message) {
        super(message);
    }
}