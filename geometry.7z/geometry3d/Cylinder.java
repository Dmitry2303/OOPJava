package geometry3d;

import geometry2d.Figure;
import exceptions.CylinderException;

public class Cylinder {
    private Figure base; // Основание цилиндра
    private double height;

    public Cylinder(Figure base, double height) throws CylinderException {
        if (base == null) {
            throw new CylinderException("Основание цилиндра не может быть null.");
        }
        if (height <= 0) {
            throw new CylinderException("Высота цилиндра должна быть положительным числом.");
        }

        this.base = base;
        this.height = height;
    }

    public double volume() {
        return base.area() * height;
    }

    @Override
    public String toString() {
        return String.format("Cylinder(base=%s, height=%.2f, volume=%.2f)", base, height, volume());
    }
}