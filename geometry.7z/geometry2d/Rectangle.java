package geometry2d;

import exceptions.FigureException;

public class Rectangle implements Figure {
    private double width;
    private double height;

    public Rectangle(double width, double height) throws FigureException {
        if (width <= 0 || height <= 0) {
            throw new FigureException("Ширина и высота должны быть положительными числами.");
        }
        this.width = width;
        this.height = height;
    }

    @Override
    public double area() {
        return width * height;
    }

    @Override
    public double perimeter() {
        return 2 * (width + height);
    }

    @Override
    public String toString() {
        return String.format("Rectangle(width=%.2f, height=%.2f)", width, height);
    }
}