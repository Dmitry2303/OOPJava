import geometry2d.Circle;
import geometry2d.Rectangle;
import geometry3d.Cylinder;
import exceptions.FigureException;
import exceptions.CylinderException;

public class Main {
    public static void main(String[] args) {
        try {
            Circle circle = new Circle(5);
            Rectangle rectangle = new Rectangle(4, 6);
            Cylinder cylinder = new Cylinder(circle, 10);

            System.out.println(circle);
            System.out.println("Circle Area: " + circle.area());
            System.out.println("Circle Perimeter: " + circle.perimeter());

            System.out.println(rectangle);
            System.out.println("Rectangle Area: " + rectangle.area());
            System.out.println("Rectangle Perimeter: " + rectangle.perimeter());

            System.out.println(cylinder);
            System.out.println("Cylinder Volume: " + cylinder.volume());

        } catch (FigureException e) {
            System.out.println("Ошибка фигуры: " + e.getMessage());
        } catch (CylinderException e) {
            System.out.println("Ошибка цилиндра: " + e.getMessage());
        }
    }
}